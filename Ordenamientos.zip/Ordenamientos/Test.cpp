#include<iostream>
#include<conio.h>
#include<ctime>
#include"Ordenamiento.h"
using namespace std;

int main()
{
	srand(time(NULL));
	
	int n = 10;
	int* arreglo = new int[n];
	Ordenamiento<int> ord = Ordenamiento<int>();
	char t;
	cin >> t;
	while (t=='M')
	{
		
		for (int i = 0; i < n; i++)
		{
			arreglo[i] = rand() % 200 + rand() % 50;
		}
		for (int i = 0; i < n; i++) {
			cout << arreglo[i] << " ";
		}
		cout << endl;
		int k = rand()%(n-2)+1; //el kesimo menor elemento del arreglo
		int e = ord.quickselect(arreglo, 0, n - 1, k);
		for (int i = 0; i < n; i++) {
			cout << arreglo[i] << " ";
		}
		cout << endl;
		
		cout << "El menor elemento en la posicion " << k << " es: " << e << '\n';
		//cout << "El kesimo elemento es: " << e << endl;
		cin.ignore();
		cin >> t;
	}
	system("pause>=NULL");
	return 0;
}