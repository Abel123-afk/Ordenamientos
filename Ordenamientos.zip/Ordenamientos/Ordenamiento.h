#pragma once
using namespace std;

typedef unsigned long long ull;
template<class T>
class Ordenamiento
{
private:
	void _swap(T* a, T* b) {
		T aux = *a;
		*a = *b;
		*b = aux;
	}
	ull particion(T* A, ull p, ull r) {
		T x = A[r]; //el pivote
		ull i = p - 1; //indice de los menores
		for (ull j = p; j < r; j++) {
			if (A[j] <= x) {
				i++;
				_swap(&A[i], &A[j]);
			}
		}
		_swap(&A[i + 1], &A[r]);
		return i + 1;
	}
public:
	Ordenamiento() {

	}
	~Ordenamiento() {}
	ull quickselect(T* A, ull p, ull r, ull k) {
		if (p == r) return A[p];
		//indice del pivote con A ordenado Izq(Menores) Der(Mayores) al pivote
		ull q = particion(A, p, r);
		ull l = q - p + 1; //nro elementos del sub arreglo donde se encuentra el kesimo elemento
		if (k == l)
			return A[q];
		else if (k < l) {
			return quickselect(A, p, q - 1, k);
		}
		else {
			return quickselect(A, p, q, k - l);
		}
	}
};
